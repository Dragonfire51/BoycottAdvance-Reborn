# BoycottAdvance-Reborn — parches `apu.c` y `flash.c`

Archivos listos para reemplazar `src/apu.c` y `src/flash.c`.
Referencia: GBATEK (secciones Sound Controller, Timers, DMA) y la lógica de `src/gba/savedata.c` de mGBA.
Verificación: `test/` (harness sintético con `gba.h` simulado, `gcc -std=c99 -Wall -Wextra` limpio):
31 comprobaciones OK con los archivos nuevos; el `flash.c` original falla 11 de ellas.

**Limitaciones de esta revisión (leer antes de aplicar):**
- No tengo acceso a tu repo vía GitKraken (es una app local). Solo vi `apu.c` y `flash.c` por sus URLs raw.
  No vi `gba.h`, `mem.c` ni `dma_run`, así que los nombres de campos de `Apu` son los que ya usa tu `apu.c`.
- GitHub bloquea la lectura de `mgba-emu/mgba/tree/master/src`; el flash sigue lo que conozco de `savedata.c`
  de mGBA (no lo leí verbatim). GBATEK se truncó antes de la sección "Cartridges": IDs y secuencias de flash
  salen de mGBA/datasheets, no de GBATEK. Sound/Timers/DMA sí los leí de GBATEK.
- Sin ROM ni mGBA en ejecución: no hay comparación de audio real. Hay que probar con Esmeralda.

## flash.c

| # | Bug | Efecto |
|---|---|---|
| F1 | **Program**: el byte de datos solo se aceptaba si la dirección era `0x5555` (y se escribía ahí). El dato va a la dirección *destino*. | Ningún byte se guardaba donde correspondía; además el comando quedaba "pegado" y bloqueaba todo lo siguiente. **Causa principal de que no se guarde.** |
| F2 | **Chip erase** (`AA 55 80 AA 55 10@5555`) no estaba implementado en la ruta real (la rama `FLASH_ERASE` era código muerto). | El comando `0x80` quedaba latcheado para siempre. |
| F3 | **Bank switch**: esperaba escritura en `0x5555` y hacía toggle. Debe ser escritura de `0/1` en `0x0000`. | Banco equivocado en cartuchos de 128K (Esmeralda). |
| F4 | `0xF0` suelto no salía del modo ID. | Cuelgues en la detección del chip en algunos drivers. |
| F5 | Sector erase con dirección `0x5555` exacta (sector 5) se confundía con un comando. | Sector 5 no se borraba. |
| F6 | Tamaño de borrado dependía de `sizeof(save_mem)`; ahora 64K/128K según `save_type`. | Robusto si `save_mem` es puntero. |

## apu.c

| # | Bug | Referencia |
|---|---|---|
| A1 | **FIFO tratado como unsigned**: `(smp-128)<<8` sobre bytes que son *signed* (0x00 = silencio). Saltos enormes en cada cruce por cero. Ahora `(int8_t)`. | Sound Channel A/B: "signed 8bit" |
| A2 | **Timers de FIFO ignoraban prescaler y cascade** (`65536-reload` en ciclos). Con F/64 el sample rate salía 64× más rápido. Ahora usa `timer_period()` y comprueba `enabled`. | Timers: TMxCNT_H bits 0-2, 2 |
| A3 | **FIFO L/R**: se sumaba a ambos lados si cualquiera estaba activo. Ahora A: bit 9=L, 8=R; B: 13=L, 12=R. | SOUNDCNT_H |
| A4 | **Volumen maestro L/R invertido**: L = bits 4-6, R = bits 0-2. | SOUNDCNT_L |
| A5 | **PSG ~136× más bajo que los FIFO** (`s*4` frente a ±32768). Ahora PSG = ¼ del rango FIFO por canal; respeta `SOUNDCNT_H` bits 0-1 (25/50/100%). | "Max Output Levels" |
| A6 | **Cuadrados una octava arriba**: paso de duty cada `8*P` ciclos; correcto `16*P`. | CH1: f = 131072/(2048-n) |
| A7 | **Wave (CH3)**: digito cada `P` ciclos; correcto `8*P` (3 octavas arriba). Nibble alto primero (estaba invertido). Volumen invertido (100% era el más bajo) y falta "force 75%" (bit 7). | CH3 |
| A8 | **Ruido** 4× demasiado rápido: `64·r·2^s` ciclos (`r=0` → `32·2^s`). | CH4: 524288/r/2^(s+1) |
| A9 | **Envolvente**: comprobaba `nr12 & 0xF8` (volumen/dir, no el periodo), paso a 256 Hz fijo y dirección invertida respecto a GBATEK. Ahora periodo = `NRx2 & 7`, un paso cada n/64 s, bit 3 = subir. | CH1 SOUND1CNT_H |
| A10 | **Deriva**: `APU_CYCLES_PER_SAMPLE` entero (380 vs 380.45). Ahora ciclos fraccionarios exactos. | — |
| A11 | UB: `byte << 24` sobre `int32_t`. | — |

Tests de pitch (1 s a 44.1 kHz): CH1 P=1024 → 256 cruces por cero (128 Hz ✓); CH3 patrón F0 → 1024 cruces (512 Hz ✓).

## Pendiente — necesito `gba.h`, `mem.c` (y `dma_run`) para tocarlo

1. **DMA de FIFO**: tu `apu_fifo_write` decía "toca el byte bajo de cada palabra". GBATEK: cada palabra de 32 bit
   trae **4 muestras** (byte bajo primero) y cada petición de DMA trae 4 palabras = 16 bytes. Si `dma_run`
   pasa `w & 0xFF` el FIFO se vacía 4× rápido → audio entrecortado/agudo. Debe ser:
   `for k<4: bytes[4*i+k] = (w >> (8*k)) & 0xFF`. Lo mismo para escrituras CPU a `FIFO_A/B` (0xA0/0xA4).
2. **Pop del FIFO y pedido de DMA en tiempo emulado**: hoy el pop ocurre dentro del callback de audio, no en el
   overflow del timer del núcleo, y nada pide DMA cuando quedan ≤16 bytes. Lo correcto (como `GBAAudioSampleFIFO` en mGBA):
   en `timer_overflow(i)`, para cada FIFO con ese timer: pop, y si `len <= 16` → `dma_trigger_fifo`. El mixer solo lee el último sample.
3. **Length counter / sweep / trigger** (tu BUG 5): requiere ver dónde `mem.c` carga `ch*_vol`, `ch*_on`, longitud
   y qué guarda `ch*_dir`. `ch*_dir` ya no se usa en `apu.c`; el contador de envolvente (`g_env_cc`) debería
   reiniciarse en el trigger (bit 15 de SOUNDxCNT_X / NR14).
4. `NR51` (habilitación L/R por canal PSG, `SOUNDCNT_L` bits 8-15) y `SOUNDCNT_X` bit 7 (master enable) no se aplican:
   no vi esos campos. `SOUNDCNT_X` bits 0-3 (flags de canal) tampoco se reportan.
5. Wave RAM de 2 bancos / 64 dígitos (`SOUND3CNT_L` bits 5-6) y `SOUNDBIAS` sin implementar.
6. Reset de FIFO (`SOUNDCNT_H` bits 11 y 15) y savestates: `g->flash` y los estáticos nuevos de `apu.c`
   (`g_frac`, `g_env_cc`, `g_fifo_a/b`) no se guardan; conviene moverlos a `Apu`/`Flash` y subir la versión del state.
7. Flash: confirmar que `save_mem` se inicializa a `0xFF` y que `save_dirty` se vuelca a disco (fuera de `flash.c`).

## Dependencias de campos (si no compila)

`apu.c` usa `g->timer[i].{reload,prescaler,count_up,enabled}` (del parche de timers de `PPU_FIXES.md §2b`),
y `Apu`: `nr11 nr12 nr13 nr21 nr22 nr23 nr32 nr33 nr42 nr43 nr50 ch{1,2,3,4}_on ch{1,2,4}_vol ch{1,2,3}_phase
ch4_cc ch4_lfsr wave sound_cnt[0] fifo{a,b}[ _head _len _held _acc]` — los mismos que ya usaba. Se asume que
`nr12/nr22/nr32/nr42/nr43` guardan el byte estilo NRxx (periodo de envolvente en bits 0-2, dirección en bit 3).
