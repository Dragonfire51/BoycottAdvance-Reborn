# BoycottAdvance-Reborn — parches PPU / registros / timers

Base analizada: `main` (v1.4.7), archivos `ppu.c`, `gba.h`, `mem.c`, `gba.c`.
Referencia: GBATEK (sección citada en cada ítem). **No** se comparó contra mGBA en ejecución
(sin red ni ROM en este entorno): la verificación hecha fue un test sintético contra la
lectura de GBATEK (`ppu_test.tar.gz`, 23/23). Falta el diff frame a frame contra mGBA.

Orden de aplicación: 1) `gba.h` → 2) `mem.c` → 3) `gba.c` → 4) reemplazar `src/ppu.c`.
Después de aplicar: `grep -rn "winin\[\|bgaffx\|bgaffy" src/` y corregir lo que quede
(win32.c / main.c no deberían usarlos).

---

## 1. `src/gba.h`

Reemplazar, dentro de `typedef struct { ... } Ppu;`, desde `int16_t bgaffx[2]...` hasta `blendy`:

```c
    int16_t  bgaffpa[2], bgaffpb[2];    /* BG2/BG3 matrix: 0=BG2 1=BG3 */
    int16_t  bgaffpc[2], bgaffpd[2];
    int32_t  bgx[2], bgy[2];            /* BG2X/Y, BG3X/Y (28-bit signed, 20.8) */
    int32_t  bgx_i[2], bgy_i[2];        /* internal ref points, +PB/PD per line */
    uint16_t winh[2], winv[2];          /* X1<<8|X2, Y1<<8|Y2 (16 bit completos) */
    uint16_t winin;                     /* WIN0 = byte bajo, WIN1 = byte alto */
    uint16_t winout;                    /* fuera = byte bajo, OBJ window = alto */
    uint16_t mosaic;
    uint16_t bldcnt;
    uint16_t blendalpha;
    uint16_t blendy;
```

En la sección `/* ppu */` agregar:

```c
void ppu_frame_start(GBA *g);
void ppu_render_line(GBA *g, int y);
```

`gba.c` (savestate): el layout de `Ppu` cambió → subir la versión del state de `1` a `2`
en `gba_save_state` (`buf[n++] = 2`) y en `gba_load_state` (`if (ver != 2) return -1;`).

---

## 2. `src/mem.c`

### 2a. Mapa de registros (GBATEK "LCD I/O BG Rotation/Scaling", "Window", "Color Effects")

El mapa actual está corrido. Real:

| Offset | Registro | Offset | Registro |
|---|---|---|---|
| 0x20/22/24/26 | BG2PA/PB/PC/PD | 0x40 / 0x42 | WIN0H / WIN1H |
| 0x28 / 0x2C | BG2X / BG2Y (32 bit) | 0x44 / 0x46 | WIN0V / WIN1V |
| 0x30/32/34/36 | BG3PA/PB/PC/PD | 0x48 | WININ (WIN0 bajo, WIN1 alto) |
| 0x38 / 0x3C | BG3X / BG3Y (32 bit) | 0x4A | WINOUT (fuera bajo, OBJ win alto) |
| 0x50 | BLDCNT | 0x4C | MOSAIC |
| 0x52 | BLDALPHA | 0x54 | BLDY |

El código actual guardaba `0x20..0x26` como `bgaffx/bgaffy` (en realidad PA..PD de BG2), `0x30`
como PA de BG2 (es BG3PA), y desplazaba WININ/WINOUT/MOSAIC/BLD*/BLDY +2. Además
`winh/winv` se enmascaraban con `& 0xFF` (perdían X1/Y1) y `winin/winout` con `0x3F` por
halfword (perdían el byte alto).

Agregar sobre `io_read16`:

```c
/* BGxX/BGxY: 28 bit con signo, se escriben por mitades; el escribir recarga el punto interno */
static void ppu_set_ref(int32_t *reg, int32_t *internal, int hi, uint16_t v) {
    uint32_t r = (uint32_t)*reg;
    if (hi) r = (r & 0x0000FFFFu) | ((uint32_t)v << 16);
    else    r = (r & 0xFFFF0000u) | v;
    r &= 0x0FFFFFFFu;
    if (r & 0x08000000u) r |= 0xF0000000u;
    *reg = (int32_t)r; *internal = (int32_t)r;
}
```

**En `io_write16`**, borrar los `case 0x020:` … `case 0x056:` actuales y poner:

```c
    case 0x020: g->ppu.bgaffpa[0] = (int16_t)v; return;
    case 0x022: g->ppu.bgaffpb[0] = (int16_t)v; return;
    case 0x024: g->ppu.bgaffpc[0] = (int16_t)v; return;
    case 0x026: g->ppu.bgaffpd[0] = (int16_t)v; return;
    case 0x028: ppu_set_ref(&g->ppu.bgx[0], &g->ppu.bgx_i[0], 0, v); return;
    case 0x02A: ppu_set_ref(&g->ppu.bgx[0], &g->ppu.bgx_i[0], 1, v); return;
    case 0x02C: ppu_set_ref(&g->ppu.bgy[0], &g->ppu.bgy_i[0], 0, v); return;
    case 0x02E: ppu_set_ref(&g->ppu.bgy[0], &g->ppu.bgy_i[0], 1, v); return;
    case 0x030: g->ppu.bgaffpa[1] = (int16_t)v; return;
    case 0x032: g->ppu.bgaffpb[1] = (int16_t)v; return;
    case 0x034: g->ppu.bgaffpc[1] = (int16_t)v; return;
    case 0x036: g->ppu.bgaffpd[1] = (int16_t)v; return;
    case 0x038: ppu_set_ref(&g->ppu.bgx[1], &g->ppu.bgx_i[1], 0, v); return;
    case 0x03A: ppu_set_ref(&g->ppu.bgx[1], &g->ppu.bgx_i[1], 1, v); return;
    case 0x03C: ppu_set_ref(&g->ppu.bgy[1], &g->ppu.bgy_i[1], 0, v); return;
    case 0x03E: ppu_set_ref(&g->ppu.bgy[1], &g->ppu.bgy_i[1], 1, v); return;
    case 0x040: g->ppu.winh[0] = v; return;
    case 0x042: g->ppu.winh[1] = v; return;
    case 0x044: g->ppu.winv[0] = v; return;
    case 0x046: g->ppu.winv[1] = v; return;
    case 0x048: g->ppu.winin  = v & 0x3F3F; return;
    case 0x04A: g->ppu.winout = v & 0x3F3F; return;
    case 0x04C: g->ppu.mosaic = v; return;
    case 0x050: g->ppu.bldcnt = v & 0x3FFF; return;
    case 0x052: g->ppu.blendalpha = v & 0x1F1F; return;
    case 0x054: g->ppu.blendy = v & 0x1F; return;
```

**En `io_read16`**, borrar los `case 0x020:` … `case 0x056:` y poner (BG2PA..BG3Y, WINxH/V,
MOSAIC y BLDY son write-only → caen al `default`, que devuelve 0):

```c
    case 0x048: return g->ppu.winin;
    case 0x04A: return g->ppu.winout;
    case 0x050: return g->ppu.bldcnt;
    case 0x052: return g->ppu.blendalpha;
```

DISPSTAT (lectura, `case 0x004`): conservar el bit HBlank que mantiene `gba.c`:

```c
        uint16_t v = g->ppu.dispstat & 0xFFF8;
        v |= g->ppu.dispstat & 0x0002;                                    /* HBlank (vivo) */
        if (g->ppu.vcount >= 160 && g->ppu.vcount != 227) v |= 0x0001;    /* VBlank */
        if (g->ppu.vcount == ((g->ppu.dispstat >> 8) & 0xFF)) v |= 0x0004;
        return v;
```

### 2b. Timers (BUG distinto, no estaba en tu lista) — GBATEK "Timer Registers"

`TMxCNT_L` (0x100,0x104,0x108,0x10C): escribir = **reload**, leer = contador.
`TMxCNT_H` (0x102,…): **control**. El código tenía ambos invertidos: escribir el control
(`0x0080`) pisaba `reload` con el valor de control, y escribir el reload pisaba el contador.
Además `io_update_timers` perdía el resto de ciclos (`1232/1024` → 1 tick en vez de 1.2),
el cascade no comprobaba `count_up`/`enabled`, y el contador en cascada no tenía overflow propio.

Reemplazar en `io_write16` los dos `case` de timers:

```c
    case 0x100: case 0x104: case 0x108: case 0x10C:      /* TMxCNT_L: reload */
        g->timer[(reg - 0x100) >> 2].reload = v; return;
    case 0x102: case 0x106: case 0x10A: case 0x10E: {    /* TMxCNT_H: control */
        Timer *tm = &g->timer[(reg - 0x102) >> 2];
        bool was = tm->enabled;
        int ps = v & 3;
        tm->prescaler  = ps == 0 ? 1 : ps == 1 ? 64 : ps == 2 ? 256 : 1024;
        tm->count_up   = (v >> 2) & 1;
        tm->irq_enable = (v >> 6) & 1;
        tm->enabled    = (v >> 7) & 1;
        if (tm->enabled && !was) { tm->counter = tm->reload; tm->clock = 0; }
        return;
    }
```

Y en `io_read16` los dos `case` de timers:

```c
    case 0x100: case 0x104: case 0x108: case 0x10C: return g->timer[(reg-0x100)>>2].counter;
    case 0x102: case 0x106: case 0x10A: case 0x10E: {
        Timer *tm = &g->timer[(reg-0x102)>>2];
        int ps = tm->prescaler == 1 ? 0 : tm->prescaler == 64 ? 1 : tm->prescaler == 256 ? 2 : 3;
        return (uint16_t)(ps | (tm->count_up << 2) | (tm->irq_enable << 6) | (tm->enabled << 7));
    }
```

Reemplazar `io_update_timers` completa:

```c
static void timer_overflow(GBA *g, int i) {
    Timer *t = &g->timer[i];
    t->counter = t->reload;
    if (t->irq_enable) g->if_reg |= (IF_TIMER0 << i);
    if (i < 3) {
        Timer *n = &g->timer[i + 1];
        if (n->enabled && n->count_up && ++n->counter == 0) timer_overflow(g, i + 1);
    }
}

void io_update_timers(GBA *g, uint32_t cycles) {
    for (int i = 0; i < 4; i++) {
        Timer *t = &g->timer[i];
        if (!t->enabled || t->count_up) continue;
        t->clock += cycles;
        uint32_t ticks = t->clock / (uint32_t)t->prescaler;
        t->clock %= (uint32_t)t->prescaler;
        while (ticks) {
            uint32_t room = 0x10000u - t->counter;
            if (ticks < room) { t->counter = (uint16_t)(t->counter + ticks); break; }
            ticks -= room;
            timer_overflow(g, i);
        }
    }
}
```

Nota: sigue siendo granular a nivel de scanline (la IRQ de timer se levanta una vez por
llamada aunque haya varios overflows). Con el split de 960/272 ciclos de 3) mejora un poco.

---

## 3. `src/gba.c` — render por scanline (tu BUG 4)

Reemplazar `run_frame_core` completa:

```c
static void run_frame_core(GBA *g) {
    const uint32_t visible_cycles = 960;     /* 240 px * 4 ciclos */
    const uint32_t hblank_cycles  = 272;     /* total 1232 por linea */

    ppu_frame_start(g);                      /* recarga puntos de referencia afines */

    for (int line = 0; line < 228; line++) {
        int vm = (g->ppu.dispstat >> 8) & 0xFF;
        g->ppu.vcount = (uint16_t)line;

        /* flags vivos de DISPSTAT: bit0 VBlank (lineas 160-226), bit2 VCount */
        uint16_t st = (uint16_t)(g->ppu.dispstat & 0xFFF8);
        if (line >= 160 && line != 227) st |= 0x0001;
        if (line == vm)                 st |= 0x0004;
        g->ppu.dispstat = st;

        if (line == 160) {
            if (st & 0x0008) g->if_reg |= IF_VBLANK;
            g->frame_count++;
            if (g->cst.halt) g->cst.halt = false;
            dma_trigger(g, 1);               /* DMA de VBlank */
        }
        if ((st & 0x0020) && line == vm) g->if_reg |= IF_VCOUNT;

        /* parte visible de la linea */
        io_update_timers(g, visible_cycles);
        arm_execute(g, visible_cycles);
        if (line < 160) ppu_render_line(g, line);   /* ve los registros tal como estan AHORA */

        /* HBlank */
        g->ppu.dispstat |= 0x0002;
        if (g->ppu.dispstat & 0x0010) g->if_reg |= IF_HBLANK;
        if (line < 160) dma_trigger(g, 2);          /* DMA de HBlank (p.ej. HDMA de scroll) */
        io_update_timers(g, hblank_cycles);
        arm_execute(g, hblank_cycles);
    }
    g->ppu.vcount = 0;
}
```

Esto es lo que hace que cambios de `BGxHOFS/VOFS`, `BLDCNT`, `WIN*`, etc. hechos por IRQ/DMA de
HBlank afecten a la linea siguiente (Pokédex, transiciones de batalla, efectos de clima).
El `ppu_render_frame` viejo queda disponible para herramientas, pero ya no se llama desde el loop.

---

## 4. `src/ppu.c`

Reemplazar el archivo completo por el `ppu.c` adjunto.

---

## Bugs encontrados en `ppu.c` original (corregidos en el nuevo)

| # | Bug | Efecto | Referencia GBATEK |
|---|---|---|---|
| 1 | Sprite: `xpos = a0 & 0x1FF` (X sale de attr1, no attr0) | X e Y salen de a0 → sprites en diagonal / mal ubicados | OBJ Attribute 0/1 |
| 2 | Bits de attr0 mal: usaba 0x0200 como "afín" y 0x0400 como "disabled" | Afín = bit 8; bit 9 = disable/double-size; bits 10-11 = modo. Los sprites semitransparentes (modo 1) se ocultaban enteros | OBJ Attribute 0 |
| 3 | `cmode = (a1 >> 13) & 1` | 256 colores está en **attr0** bit 13; en attr1 bit 13 es V-flip | OBJ Attribute 0/1 |
| 4 | Test de transparencia `palidx == 0` **después** de `\|= palbank<<4` (BG y OBJ) | Con banco de paleta ≠ 0, el color 0 se dibujaba opaco → cajas alrededor de sprites/tiles | BG/OBJ 4bpp |
| 5 | Banco de paleta de BG tomado de `BGxCNT` bits 4-7 | Es el bits 12-15 de la **entrada del mapa**. Colores equivocados en todo BG de 16 colores | BG Screen Data Format |
| 6 | OBJ base VRAM según DISPCNT bit 5 | Bit 5 es "HBlank free"; base = 0x10000 (modos 0-2) o 0x14000 (modos 3-5) | LCD VRAM Overview |
| 7 | Sprites 256 colores usaban pasos de 32 bytes por tile | Cada tile 8bpp ocupa 2 slots (64 bytes) | OBJ Attribute 2 / VRAM mapping |
| 8 | Prioridad: BG con `pri < bgpri` dibujando de BG3→BG0 | A igual prioridad ganaba el BG de **mayor** número (debe ganar el menor) | LCD BG Control |
| 9 | Sprites iterados en orden ascendente con `<=` | A igual prioridad ganaba el OAM de mayor índice (debe ganar el menor) | OBJ priority |
| 10 | Modo 2 dibujaba BG0/BG1 de texto | En modo 2 solo existen BG2/BG3 afines | LCD BG Modes |
| 11 | BG afín: tamaño `128 << (size&1)` | Debe ser cuadrado 128/256/512/1024; además ignoraba el bit 13 (wrap) | BG Control bit 13/14-15 |
| 12 | BG afín usaba `bgaffx/bgaffy` (en realidad PA..PD) como punto de referencia, y BG3 nunca se dibujaba | Todo BG afín mal | BG Rotation/Scaling |
| 13 | `read_vram*` con `& 0x1FFFF` sobre un array de 0x18000 bytes | Lectura fuera de rango en 0x18000-0x1FFFF (espejo) | Memory map |
| 14 | `render_line` dibujaba **todos** los sprites completos en cada línea (160×) | Muy lento e incompatible con render por línea | — |
| 15 | Forced blank (DISPCNT bit 7) no producía pantalla blanca | — | DISPCNT |
| 16 | `winh/winv` `& 0xFF`, `winin/winout` `& 0x3F` por halfword, regs corridos +2 | Ventanas/blend inutilizables aunque se implementaran | Window/Color Effects |
| 17 | Timers: control ↔ reload invertidos, resto de ciclos perdido, cascade sin overflow | Timing de juego/RNG/audio incorrecto | Timer Registers |

## Todavía NO cubierto (verificar a continuación)

- **Mosaico de sprites** (attr0 bit 12): no implementado (BG sí).
- **BG afín en modos bitmap 3/4/5** (rotación de bitmaps con BG2PA..): no implementado.
- **Límite de sprites por línea / ciclos de OAM**: no emulado.
- **DMA de sonido** (`mem.c` `dma_run`, modo FIFO): copia solo el byte bajo de cada palabra (`bytes[i] = w & 0xFF`). Un FIFO recibe 4 muestras de 8 bit por palabra. Sospecha fuerte; comparar contra `src/gba/audio.c` de mGBA antes de tocar.
- **Escrituras de 8 bit a PAL/VRAM de BG**: el hardware duplica el byte en ambas mitades del halfword; `gba_write8` escribe un solo byte.
- **`SOUNDCNT_X` (0x84)**: devuelve siempre el bit maestro; las flags de canal activo (bits 0-3) no se reportan.
- **DMA**: `count` de DMA0-2 debería enmascararse a 14 bits; la lectura de `DMAxCNT_H` no devuelve el bit de repeat (bit 9).
- **Savestate**: no guarda `g->flash` (bank / estado del comando).
- Tu BUG 5 (length counter / sweep / frame sequencer) y BUG 6 (guardado flash end-to-end) siguen igual: no toqué `apu.c` ni `flash.c` porque no los pasaste.

## Verificación hecha / pendiente

Hecho (ver `ppu_test.tar.gz`, `make`-less, `gcc -std=c99 -Wall -Wextra` limpio):
23 aserciones sintéticas — forced blank, banco de paleta de BG, transparencia 4bpp (BG y OBJ),
posición X/Y del OBJ, orden por índice OAM y prioridad, OBJ afín identidad y 2× con double-size,
alpha (EVA=EVB=8 → `0x3C0F`), brighten (`0x3DF7`), darken (`0x0008`), WIN0 con X2 exclusivo,
BG3 afín en modo 2, modo 2 sin BG0, empate de prioridad BG0>BG1.

Pendiente en tu entorno (obligatorio antes de commitear):
1. `make`, `make -f Makefile.win32`, `make -f Makefile.win32 ARCH=i686` limpios.
2. Diff frame a frame contra mGBA con Esmeralda: `DISPCNT`, `BLDCNT`/`BLDALPHA`/`BLDY`,
   `WININ/WINOUT`, framebuffer en los frames del título, un fade a negro, una batalla y la
   pantalla del Pokédex. mGBA: `src/gba/renderers/video-software.c`, `software-bg.c`,
   `software-obj.c`, `software-mode0.c`.
3. Actualizar `AGENTS.md` (causa raíz de cada ítem de la tabla, commit, números antes/después).
