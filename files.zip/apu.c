/*
 * apu.c - GBA sound: 4 PSG channels + Direct Sound FIFOs.
 *
 * Reference: GBATEK "GBA Sound Controller" / "GBA Timers" / "GBA DMA Transfers".
 * All timing below is in CPU cycles (16.777216 MHz):
 *   square  : 1 duty step (of 8) every 16 * (2048-n) cycles   (f = 131072/(2048-n))
 *   wave    : 1 digit (of 32)    every  8 * (2048-n) cycles   (2097152/(2048-n) digits/s)
 *   noise   : 1 LFSR clock every 64 * r * 2^s cycles, r=0 -> 32 * 2^s
 *   envelope: 1 step every n/64 s = n * 262144 cycles (n = NRx2 bits 0-2, 0 = off)
 */
#include <stdint.h>
#include "gba.h"
#include "mem.h"

#define CPU_HZ 16777216u

static const uint32_t DUTY[4] = { 1, 2, 4, 6 };   /* high steps out of 8 */

static int16_t  g_fifo_a, g_fifo_b;     /* last DAC value of each FIFO (16-bit scale) */
static uint32_t g_frac;                 /* fractional CPU cycles per output sample    */
static uint32_t g_env_cc[3];            /* envelope cycle counters: ch1, ch2, ch4     */

/* Pop one signed 8-bit sample; an empty FIFO holds the last value. */
static int fifo_pop(int32_t *buf, int *head, int *len, int32_t *held) {
    if (*len > 0) {
        *held = buf[*head];
        *head = (*head + 1) & 31;
        (*len)--;
    }
    return (int8_t)((uint32_t)*held >> 24);
}

/* One envelope step every n/64 s; NRx2 bit 3: 1 = increase, 0 = decrease. */
static int env_tick(uint32_t *cc, uint32_t step, uint32_t nrx2, int vol) {
    uint32_t n = nrx2 & 7;
    if (!n) { *cc = 0; return vol; }
    uint32_t len = n * 262144u;
    *cc += step;
    while (*cc >= len) {
        *cc -= len;
        if (nrx2 & 8) { if (vol < 15) vol++; }
        else if (vol > 0) vol--;
    }
    return vol;
}

/* Timer overflow period in CPU cycles (prescaler and cascade included). */
static uint64_t timer_period(const GBA *g, int idx) {
    const Timer *t = &g->timer[idx];
    uint64_t per = 0x10000u - (uint32_t)t->reload;
    if (t->count_up && idx > 0) return per * timer_period(g, idx - 1);
    return per * (t->prescaler ? (uint32_t)t->prescaler : 1u);
}

void apu_mix(GBA *g, int16_t *stream, int nframes) {
    Apu *a = &g->apu;

    for (int i = 0; i < nframes; i++) {
        /* exact cycles per output sample (e.g. 380.45 at 44.1 kHz), no drift */
        uint32_t step = CPU_HZ / APU_SR;
        g_frac += CPU_HZ % APU_SR;
        if (g_frac >= APU_SR) { g_frac -= APU_SR; step++; }

        /* --- volume envelopes (ch1, ch2, ch4) --- */
        if (a->ch1_on) a->ch1_vol = env_tick(&g_env_cc[0], step, a->nr12, a->ch1_vol);
        if (a->ch2_on) a->ch2_vol = env_tick(&g_env_cc[1], step, a->nr22, a->ch2_vol);
        if (a->ch4_on) a->ch4_vol = env_tick(&g_env_cc[2], step, a->nr42, a->ch4_vol);

        /* PSG sum, each channel in -15..+15 */
        int32_t s = 0;

        /* --- channels 1/2 (square) --- */
        if (a->ch1_on && a->ch1_vol) {
            uint32_t period = 2048 - (a->nr13 & 0x7FF);
            a->ch1_phase += (step << 16) / (period * 16);
            if (((a->ch1_phase >> 16) & 7) < DUTY[(a->nr11 >> 6) & 3]) s += a->ch1_vol;
            else s -= a->ch1_vol;
        }
        if (a->ch2_on && a->ch2_vol) {
            uint32_t period = 2048 - (a->nr23 & 0x7FF);
            a->ch2_phase += (step << 16) / (period * 16);
            if (((a->ch2_phase >> 16) & 7) < DUTY[(a->nr21 >> 6) & 3]) s += a->ch2_vol;
            else s -= a->ch2_vol;
        }

        /* --- channel 3 (wave RAM) ---
           volume code (NR32 bits 5-6): 0=mute 1=100% 2=50% 3=25%; bit 7 forces 75%.
           Digits play high nibble first. */
        {
            int code = (a->nr32 >> 5) & 3;
            int force75 = (a->nr32 >> 7) & 1;
            if (a->ch3_on && (code || force75)) {
                uint32_t period = 2048 - (a->nr33 & 0x7FF);
                a->ch3_phase += (step << 16) / (period * 8);
                uint32_t pos = (a->ch3_phase >> 16) & 31;
                uint8_t w = a->wave[pos >> 1];
                int nib = (pos & 1) ? (w & 0xF) : (w >> 4);
                int v = nib * 2 - 15;                    /* -15..+15 */
                if (force75)       v = v * 3 / 4;
                else if (code == 2) v = v / 2;
                else if (code == 3) v = v / 4;
                s += v;
            }
        }

        /* --- channel 4 (noise) --- */
        if (a->ch4_on && a->ch4_vol) {
            uint32_t r = a->nr43 & 7, sh = (a->nr43 >> 4) & 0xF;
            uint32_t period = r ? ((64u * r) << sh) : (32u << sh);
            a->ch4_cc += step;
            while (a->ch4_cc >= period) {
                a->ch4_cc -= period;
                int bit = (a->ch4_lfsr ^ (a->ch4_lfsr >> 1)) & 1;
                a->ch4_lfsr = (a->ch4_lfsr >> 1) | (bit << 14);
                if (a->nr43 & 8) a->ch4_lfsr = (a->ch4_lfsr & ~(1u << 6)) | (bit << 6);
            }
            if (a->ch4_lfsr & 1) s += a->ch4_vol; else s -= a->ch4_vol;
        }

        /* --- FIFO A / B (Direct Sound), SOUNDCNT_H ---
           bits 2/3 vol (0=50% 1=100%), 8/9 A right/left, 10 A timer,
           12/13 B right/left, 14 B timer. One sample per timer overflow. */
        uint16_t h = (uint16_t)a->sound_cnt[0];
        if (h & 0x0300) {
            int ti = (h >> 10) & 1;
            if (g->timer[ti].enabled) {
                uint64_t p = timer_period(g, ti);
                uint32_t per = p > 0xFFFFFFFFu ? 0xFFFFFFFFu : (uint32_t)p;
                a->fifo_acc_a += step;
                while (a->fifo_acc_a >= per) {
                    a->fifo_acc_a -= per;
                    int smp = fifo_pop(a->fifoa, &a->fifoa_head, &a->fifoa_len, &a->fifoa_held);
                    g_fifo_a = (int16_t)(smp * 256);     /* signed 8 bit -> 16 bit */
                }
            }
        }
        if (h & 0x3000) {
            int ti = (h >> 14) & 1;
            if (g->timer[ti].enabled) {
                uint64_t p = timer_period(g, ti);
                uint32_t per = p > 0xFFFFFFFFu ? 0xFFFFFFFFu : (uint32_t)p;
                a->fifo_acc_b += step;
                while (a->fifo_acc_b >= per) {
                    a->fifo_acc_b -= per;
                    int smp = fifo_pop(a->fifob, &a->fifob_head, &a->fifob_len, &a->fifob_held);
                    g_fifo_b = (int16_t)(smp * 256);
                }
            }
        }
        int32_t fa = (h & 0x04) ? g_fifo_a : (g_fifo_a >> 1);
        int32_t fb = (h & 0x08) ? g_fifo_b : (g_fifo_b >> 1);

        /* --- PSG: GBATEK max per channel = 1/4 of a FIFO (+-0x80 vs +-0x200).
           15 units -> 8192 (16-bit scale). SOUNDCNT_H bits 0-1: 25/50/100%. */
        static const int psg_mul[4] = { 1, 2, 4, 4 };
        int32_t psg = s * 546 * psg_mul[h & 3] / 4;

        /* SOUNDCNT_L (NR50): bits 0-2 = RIGHT volume, bits 4-6 = LEFT volume. */
        int vol_r = (a->nr50 & 7) + 1, vol_l = ((a->nr50 >> 4) & 7) + 1;
        int32_t pl = psg * vol_l / 8, pr = psg * vol_r / 8;

        int32_t l = pl, r = pr;
        if (h & 0x0200) l += fa;
        if (h & 0x0100) r += fa;
        if (h & 0x2000) l += fb;
        if (h & 0x1000) r += fb;

        if (l > 32767) l = 32767;
        if (l < -32768) l = -32768;
        if (r > 32767) r = 32767;
        if (r < -32768) r = -32768;
        stream[i*2]   = (int16_t)l;
        stream[i*2+1] = (int16_t)r;
    }
}

void apu_open(void) { }
void apu_close(void) { }

/* Push bytes into FIFO A (ch=0) or B (ch=1). Called from the DMA engine / the
   FIFO_x I/O registers. Each 32-bit word delivers FOUR samples, least
   significant byte first (GBATEK FIFO_A_L: "Data 0 being located in least
   significant byte which is replayed first"). Samples are signed 8 bit. */
void apu_fifo_write(GBA *g, int ch, const uint8_t *bytes, int nbytes) {
    Apu *a = &g->apu;
    int32_t *buf = ch ? a->fifob : a->fifoa;
    int *head = ch ? &a->fifob_head : &a->fifoa_head;
    int *len  = ch ? &a->fifob_len  : &a->fifoa_len;
    for (int i = 0; i < nbytes; i++) {
        if (*len >= 32) break;                 /* FIFO is full (8 words) */
        int idx = (*head + *len) & 31;
        buf[idx] = (int32_t)((uint32_t)bytes[i] << 24);
        (*len)++;
    }
}
