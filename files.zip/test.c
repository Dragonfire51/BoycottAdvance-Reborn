#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "gba.h"
static int fails, n;
#define CHECK(c) do{n++; if(!(c)){fails++; printf("FAIL line %d: %s\n",__LINE__,#c);}}while(0)
static GBA g;
static void W(uint32_t a, uint8_t v){ flash_write(&g,a,v); }
static void unlock(void){ W(0x5555,0xAA); W(0x2AAA,0x55); }
static void cmd(uint8_t c){ unlock(); W(0x5555,c); }
static void settle(void){ for(int i=0;i<100;i++) flash_read(&g,0x100); }
static void flash_tests(void){
    memset(&g,0,sizeof g); g.save_type=SAVE_FLASH128; memset(g.save_mem,0xFF,sizeof g.save_mem); flash_init(&g);
    /* ID mode */
    cmd(0x90); CHECK(flash_read(&g,0)==0x62 && flash_read(&g,1)==0x13);
    cmd(0xF0); CHECK(flash_read(&g,0)==0xFF);
    cmd(0x90); W(0x1234,0xF0); CHECK(flash_read(&g,0)==0xFF);       /* lone F0 */
    /* program at ARBITRARY address (old code only accepted 0x5555) */
    cmd(0xA0); W(0x0123,0x5A); settle(); CHECK(flash_read(&g,0x0123)==0x5A);
    CHECK(g.save_dirty);
    cmd(0xA0); W(0x0123,0x0F); settle(); CHECK(flash_read(&g,0x0123)==0x0A);   /* AND */
    W(0x0200,0x11); settle(); CHECK(flash_read(&g,0x0200)==0xFF);   /* stray write ignored */
    /* busy polling: bit7 inverted during settle */
    cmd(0xA0); W(0x0300,0x80); CHECK((flash_read(&g,0x0300)&0x80)!=0x80); settle(); CHECK(flash_read(&g,0x0300)==0x80);
    /* sector erase (4K) via any address in the sector */
    g.save_mem[0x3010]=0; g.save_mem[0x4010]=0;
    cmd(0x80); unlock(); W(0x3ABC,0x30); settle();
    CHECK(g.save_mem[0x3010]==0xFF && g.save_mem[0x4010]==0);
    /* sector 5 erased through address 0x5555 itself */
    g.save_mem[0x5001]=0; cmd(0x80); unlock(); W(0x5555,0x30); settle(); CHECK(g.save_mem[0x5001]==0xFF);
    /* bank switch: value written to address 0 */
    cmd(0xB0); W(0x0000,1); cmd(0xA0); W(0x0042,0x77); settle(); CHECK(flash_read(&g,0x42)==0x77);
    CHECK(g.save_mem[0x10042]==0x77 && g.save_mem[0x42]==0xFF);
    cmd(0xB0); W(0x0000,0); CHECK(flash_read(&g,0x42)==0xFF);
    /* chip erase wipes both banks */
    g.save_mem[0x10]=0; g.save_mem[0x10010]=0;
    cmd(0x80); unlock(); W(0x5555,0x10); settle();
    CHECK(g.save_mem[0x10]==0xFF && g.save_mem[0x10010]==0xFF);
    /* command not stuck after erase: a normal program still works */
    cmd(0xA0); W(0x0009,0x12); settle(); CHECK(flash_read(&g,9)==0x12);
    /* 64K chip: Panasonic ID, bank switch ignored */
    memset(&g,0,sizeof g); g.save_type=SAVE_FLASH64; memset(g.save_mem,0xFF,sizeof g.save_mem); flash_init(&g);
    cmd(0x90); CHECK(flash_read(&g,0)==0x32 && flash_read(&g,1)==0x1B); cmd(0xF0);
    cmd(0xB0); W(0,1); CHECK(g.flash.bank==0);
}
static int zero_cross(const int16_t*s,int nf){int c=0;for(int i=1;i<nf;i++) if((s[2*i-2]<0)!=(s[2*i]<0)) c++; return c;}
static void apu_tests(void){
    static int16_t out[44100*2];
    memset(&g,0,sizeof g);
    g.apu.nr50=0x77; g.apu.sound_cnt[0]=2;                 /* PSG 100% */
    /* ch1: P=1024 -> 131072/1024 = 128 Hz -> ~256 crossings in 1 s */
    g.apu.ch1_on=1; g.apu.ch1_vol=15; g.apu.nr11=0x80; g.apu.nr12=0xF0; g.apu.nr13=2048-1024;
    apu_mix(&g,out,44100); int z=zero_cross(out,44100); printf("ch1 crossings=%d (expect ~256)\n",z);
    CHECK(z>=250 && z<=262);
    /* envelope decreasing: nr12 = vol F, dir 0, period 1 -> 1 step / 1/64 s ; ~15/64 s to reach 0 */
    memset(&g,0,sizeof g); g.apu.nr50=0x77; g.apu.sound_cnt[0]=2;
    g.apu.ch1_on=1; g.apu.ch1_vol=15; g.apu.nr11=0x80; g.apu.nr12=0xF1; g.apu.nr13=2048-1024;
    apu_mix(&g,out,44100/2); CHECK(g.apu.ch1_vol==0);
    memset(&g,0,sizeof g); g.apu.nr50=0x77; g.apu.sound_cnt[0]=2;
    g.apu.ch1_on=1; g.apu.ch1_vol=0; g.apu.nr12=0x09 /*inc, period1*/; g.apu.nr13=2048-1024; g.apu.nr11=0x80;
    apu_mix(&g,out,44100/2); CHECK(g.apu.ch1_vol==15);
    /* ch3: high nibble first, volume 100% > 50% > 25%, force 75% */
    memset(&g,0,sizeof g); g.apu.nr50=0x77; g.apu.sound_cnt[0]=2; g.apu.ch3_on=1; g.apu.nr33=0; g.apu.wave[0]=0xF0;
    g.apu.nr32=0x20; apu_mix(&g,out,20); int a100=out[0]; CHECK(a100>0);
    memset(&g.apu.ch3_phase,0,4); g.apu.nr32=0x40; apu_mix(&g,out,20); int a50=out[0];
    memset(&g.apu.ch3_phase,0,4); g.apu.nr32=0x60; apu_mix(&g,out,20); int a25=out[0];
    memset(&g.apu.ch3_phase,0,4); g.apu.nr32=0x80; apu_mix(&g,out,20); int a75=out[0];
    printf("ch3 vol: 100=%d 50=%d 25=%d force75=%d\n",a100,a50,a25,a75);
    CHECK(a100>a50 && a50>a25 && a25>0 && a75>a50 && a75<a100);
    memset(&g.apu.ch3_phase,0,4); g.apu.nr32=0x00; apu_mix(&g,out,20); CHECK(out[0]==0);   /* mute */
    /* ch3 rate: P=2048-n=2048 -> 1024 digits/s; 0xF0 pattern = 1 high,1 low digit -> 512 Hz */
    memset(&g.apu.ch3_phase,0,4); g.apu.nr32=0x20; for(int i=0;i<16;i++) g.apu.wave[i]=0xF0;
    apu_mix(&g,out,44100); z=zero_cross(out,44100); printf("ch3 crossings=%d (expect ~1024)\n",z); CHECK(z>=1000&&z<=1050);
    /* noise: r=1,s=0 -> 262144 Hz LFSR clock; just verify it runs and is bounded */
    memset(&g,0,sizeof g); g.apu.nr50=0x77; g.apu.sound_cnt[0]=2; g.apu.ch4_on=1; g.apu.ch4_vol=15; g.apu.nr43=0x41; g.apu.ch4_lfsr=0x7FFF;
    apu_mix(&g,out,1000); int mx=0; for(int i=0;i<2000;i++) if(abs(out[i])>mx) mx=abs(out[i]); CHECK(mx>0 && mx<=32767);
    /* FIFO: signed 8-bit. bytes 00 7F FF 80 -> 0, +127, -1, -128 (old code treated them as unsigned-128) */
    memset(&g,0,sizeof g); g.apu.nr50=0x77; g.apu.sound_cnt[0]=0x0304 /*A L+R,100%,timer0*/;
    g.timer[0].enabled=1; g.timer[0].prescaler=1; g.timer[0].reload=65536-4096; /* 4096 cycles/sample */
    uint8_t b[4]={0x00,0x7F,0xFF,0x80}; apu_fifo_write(&g,0,b,4);
    apu_mix(&g,out,60); int seen_p=0,seen_m1=0,seen_min=0;
    for(int i=0;i<60;i++){ if(out[2*i]==32512) seen_p=1; if(out[2*i]==-256) seen_m1=1; if(out[2*i]==-32768) seen_min=1; }
    CHECK(seen_p && seen_m1 && seen_min); CHECK(out[0]==0);
    /* FIFO prescaler: F/64 timer must pop 64x slower */
    memset(&g,0,sizeof g); g.apu.nr50=0x77; g.apu.sound_cnt[0]=0x0304;
    g.timer[0].enabled=1; g.timer[0].prescaler=64; g.timer[0].reload=65536-64; /* 4096 cycles */
    apu_fifo_write(&g,0,b,4); apu_mix(&g,out,20); CHECK(g.apu.fifoa_len==3);   /* 20 samples = 7609 cycles = 1 overflow of 4096 */
    /* stereo routing: A only on LEFT */
    memset(&g,0,sizeof g); g.apu.nr50=0x77; g.apu.sound_cnt[0]=0x0204; g.timer[0].enabled=1; g.timer[0].prescaler=1; g.timer[0].reload=65536-100;
    uint8_t c[2]={0x40,0x40}; apu_fifo_write(&g,0,c,2); apu_mix(&g,out,4); CHECK(out[2]>0 && out[3]==0);
    /* master volume: LEFT is bits 4-6, RIGHT bits 0-2 */
    memset(&g,0,sizeof g); g.apu.sound_cnt[0]=2; g.apu.nr50=0x70; g.apu.ch1_on=1; g.apu.ch1_vol=15; g.apu.nr11=0x80; g.apu.nr13=2048-1024;
    apu_mix(&g,out,5); CHECK(abs(out[0])>abs(out[1]));
}
int main(void){ flash_tests(); apu_tests(); printf("%d checks, %d failed\n",n,fails); return fails!=0; }
